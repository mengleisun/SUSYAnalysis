#include<string>
#include<iostream>
#include<fstream>
#include<sstream>
#include<algorithm>

#include "TFile.h"
#include "TTree.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TCanvas.h"
#include "TStyle.h"
#include "TString.h"
#include "TChain.h"
#include "TSystem.h"
#include "TMath.h"
#include "TLegend.h"
#include "TLine.h"
#include "TProfile.h"
#include "TLorentzVector.h"
#include "TFileCollection.h"

#include "analysis_rawData.h"
#include "analysis_photon.h"
#include "analysis_muon.h"
#include "analysis_ele.h"
#include "analysis_tools.h"
#include "analysis_rawData.cc"
#include "analysis_ele.cc"
#include "analysis_photon.cc"
#include "analysis_muon.cc"


void analysis_bgtemplate(const char *inputfile, const char *outputfile){//main  

  //gSystem->Load("/uscms/home/tmishra/work/CMSSW_10_2_22/src/SUSYAnalysis/lib/libAnaClasses.so");

  //char onutputname[100] = "plot_bgtemplate_FullEcal.root";
  ofstream logfile;
  logfile.open("plot_bgtemplate_FullEcal.log"); 

  logfile << "analysis_bgtemplate()" << std::endl;
  logfile << "no FSR before push photon into collection" << std::endl;

  RunType datatype(SingleMuon2016); 
  TFile *f = TFile::Open(inputfile);
  TTree *es =(TTree*)f->Get("ggNtuplizer/EventTree");
  
  es->SetBranchStatus("*",0);
  es->SetBranchStatus("EventTag", 1);
  es->SetBranchStatus("nMC", 1);
  es->SetBranchStatus("mcPID", 1);
  es->SetBranchStatus("mcPt", 1);
  es->SetBranchStatus("mcMass", 1);
  es->SetBranchStatus("mcEta", 1);
  es->SetBranchStatus("mcPhi", 1);
  es->SetBranchStatus("mcE", 1);
  es->SetBranchStatus("mcEt", 1);
  es->SetBranchStatus("mcStatusFlag", 1);
  es->SetBranchStatus("mcStatus", 1);
  es->SetBranchStatus("mcGMomPID", 1);
  es->SetBranchStatus("mcMomPID", 1);
  es->SetBranchStatus("mcMomPt", 1);
  es->SetBranchStatus("mcMomMass", 1);
  es->SetBranchStatus("mcMomEta", 1);
  es->SetBranchStatus("mcMomPhi", 1);
  es->SetBranchStatus("genMET", 1);
  es->SetBranchStatus("genMETPhi", 1);
  es->SetBranchStatus("run", 1);
  es->SetBranchStatus("event", 1);
  es->SetBranchStatus("lumis", 1);
  es->SetBranchStatus("nVtx", 1);
  es->SetBranchStatus("nGoodVtx", 1);
  es->SetBranchStatus("isPVGood", 1);
  es->SetBranchStatus("rho", 1);
  es->SetBranchStatus("HLTEleMuX", 1);
  es->SetBranchStatus("HLTPho", 1);
  es->SetBranchStatus("HLTJet", 1);
  es->SetBranchStatus("HLTEleMuXIsPrescaled", 1);
  es->SetBranchStatus("HLTPhoIsPrescaled", 1);
  es->SetBranchStatus("pfMET", 1);
  es->SetBranchStatus("pfMETPhi", 1);
  es->SetBranchStatus("pfMET_T1JERUp", 1);
  es->SetBranchStatus("pfMET_T1JERDo", 1);
  es->SetBranchStatus("pfMET_T1JESUp", 1);
  es->SetBranchStatus("pfMET_T1JESDo", 1);
  es->SetBranchStatus("pfMETPhi_T1JESUp", 1);
  es->SetBranchStatus("pfMETPhi_T1JESDo", 1);
  es->SetBranchStatus("pfMETPhi_T1UESUp", 1);
  es->SetBranchStatus("pfMETPhi_T1UESDo", 1);
  es->SetBranchStatus("nPho", 1);
  es->SetBranchStatus("phoE", 1);
  es->SetBranchStatus("phoEt", 1);
  es->SetBranchStatus("phoCalibEt", 1);
  es->SetBranchStatus("phoEta", 1);
  es->SetBranchStatus("phoPhi", 1);
  es->SetBranchStatus("phoSCEta", 1);
  es->SetBranchStatus("phoSCPhi", 1);
  es->SetBranchStatus("phohasPixelSeed", 1);
  es->SetBranchStatus("phoEleVeto", 1);
  es->SetBranchStatus("phoR9Full5x5", 1);
  es->SetBranchStatus("phoHoverE", 1);
  es->SetBranchStatus("phoSigmaIEtaIEtaFull5x5", 1);
  es->SetBranchStatus("phoPFChIso", 1);
  es->SetBranchStatus("phoPFPhoIso", 1);
  es->SetBranchStatus("phoPFNeuIso", 1);
  es->SetBranchStatus("phoFiredSingleTrgs", 1);
  es->SetBranchStatus("phoFiredDoubleTrgs", 1);
  es->SetBranchStatus("phoFiredL1Trgs", 1);
  es->SetBranchStatus("phoIDbit", 1);
  es->SetBranchStatus("nMu", 1);
  es->SetBranchStatus("muPt", 1);
  es->SetBranchStatus("muEn", 1);
  es->SetBranchStatus("muEta", 1);
  es->SetBranchStatus("muPhi", 1);
  es->SetBranchStatus("muCharge", 1);
  es->SetBranchStatus("muType", 1);
  es->SetBranchStatus("muIDbit", 1);
  es->SetBranchStatus("muD0", 1);
  es->SetBranchStatus("muDz", 1);
  es->SetBranchStatus("muPFMiniIso", 1);
  es->SetBranchStatus("muPFChIso", 1);
  es->SetBranchStatus("muPFPhoIso", 1);
  es->SetBranchStatus("muPFNeuIso", 1);
  es->SetBranchStatus("muPFPUIso", 1);
  es->SetBranchStatus("muFiredTrgs", 1);
  es->SetBranchStatus("muFiredL1Trgs", 1);
  es->SetBranchStatus("nEle", 1);
  es->SetBranchStatus("eleCharge", 1);
  es->SetBranchStatus("eleEn", 1);
  es->SetBranchStatus("eleD0", 1);
  es->SetBranchStatus("eleDz", 1);
  es->SetBranchStatus("elePt", 1);
  es->SetBranchStatus("eleCalibPt", 1);
  es->SetBranchStatus("eleCalibEn", 1);
  es->SetBranchStatus("eleEta", 1);
  es->SetBranchStatus("eleSCEta", 1);
  es->SetBranchStatus("elePhi", 1);
  es->SetBranchStatus("eleR9", 1);
  es->SetBranchStatus("eleHoverE", 1);
  es->SetBranchStatus("eleEoverPInv", 1);
  es->SetBranchStatus("eleSigmaIEtaIEtaFull5x5", 1);
  es->SetBranchStatus("eleConvVeto", 1);
  es->SetBranchStatus("eleMissHits", 1);
  es->SetBranchStatus("elePFChIso", 1);
  es->SetBranchStatus("elePFPhoIso", 1);
  es->SetBranchStatus("elePFNeuIso", 1);
  es->SetBranchStatus("elePFPUIso", 1);
  es->SetBranchStatus("elePFMiniIso", 1);
  es->SetBranchStatus("eleTrkdxy", 1);
  es->SetBranchStatus("eledEtaAtVtx", 1);
  es->SetBranchStatus("eledPhiAtVtx", 1);
  es->SetBranchStatus("eleFiredSingleTrgs", 1);
  es->SetBranchStatus("eleFiredDoubleTrgs", 1);
  es->SetBranchStatus("eleFiredL1Trgs", 1);
  es->SetBranchStatus("eleIDbit", 1);
  es->SetBranchStatus("nJet", 1);
  es->SetBranchStatus("jetPt", 1);
  es->SetBranchStatus("jetEn", 1);
  es->SetBranchStatus("jetEta", 1);
  es->SetBranchStatus("jetPhi", 1);
  es->SetBranchStatus("jetArea", 1);
  es->SetBranchStatus("jetJECUnc", 1);
  es->SetBranchStatus("jetCSV2BJetTags", 1);

  TFile *output = TFile::Open(outputfile,"RECREATE");
  output->cd();

  int   tracks(0);
  int   nVertex(0); 
  int   mcType = MCType::NOMC;
  if(datatype == MC && mcType == MCType::NOMC){std::cout << "wrong MC type" << std::endl; throw;} 
  logfile << "mcType" << mcType << std::endl;
 
  TTree *mtree = new TTree("BGTree","BGTree");
  float tagEta_mg;
  float tagPhi_mg;
  float tagPt_mg;
  float probeEta_mg;
  float probePhi_mg;
  float probePt_mg;
  float probeUncalibPt_mg;
  float invmass_mg;
  bool  vetovalue_mg;
	bool  FSRveto_mg;

  mtree->Branch("tracks",              &tracks);
  mtree->Branch("nVertex",             &nVertex);
  mtree->Branch("tagEta",              &tagEta_mg);
  mtree->Branch("tagPhi",              &tagPhi_mg);
  mtree->Branch("tagPt",               &tagPt_mg);
  mtree->Branch("probeEta",            &probeEta_mg);
  mtree->Branch("probePhi",            &probePhi_mg);
  mtree->Branch("probePt",             &probePt_mg);
  mtree->Branch("probeUncalibPt",      &probeUncalibPt_mg);
  mtree->Branch("invmass",             &invmass_mg);
  mtree->Branch("vetovalue",           &vetovalue_mg);
	mtree->Branch("FSRveto",             &FSRveto_mg);
  
  const unsigned nEvts = es->GetEntries(); 
  logfile << "Total event: " << nEvts << std::endl;
  
  rawData raw(es, datatype);
  std::vector<recoPhoton> Photon;
  std::vector<recoMuon>   Muon;
  std::vector<recoEle>   Ele;
  float MET(0);
  float METPhi(0);
  int   ntrks(0);
  int   nvtx(0);
  cout<<"Total entries: "<<nEvts<<endl;

    for (unsigned ievt(0); ievt<nEvts; ++ievt){//loop on entries
  
      if (ievt%100000==0) std::cout << " -- Processing event " << ievt << std::endl;

        raw.GetData(es, ievt);
        Photon.clear();
        Muon.clear();
        Ele.clear();
        for(int iPho(0); iPho < raw.nPho; iPho++){Photon.push_back(recoPhoton(raw, iPho));}
        for(int iMu(0); iMu < raw.nMu; iMu++){Muon.push_back(recoMuon(raw, iMu));}
        for(int iEle(0); iEle < raw.nEle; iEle++){Ele.push_back(recoEle(raw, iEle));}
        MET = raw.pfMET;
        METPhi = raw.pfMETPhi;
        nvtx = raw.nVtx;

        tracks = ntrks;
        nVertex = nvtx;
        if(MET > 70.0)continue;
        if(!raw.passHLT())continue;

        std::vector< std::vector<recoMuon>::iterator > bgMuCollection;
        bgMuCollection.clear();
				for(std::vector<recoMuon>::iterator itMu = Muon.begin(); itMu != Muon.end(); itMu++){
					if(itMu->getPt() < 30)continue;
					if(fabs(itMu->getEta() > 2.1))continue;
					if(itMu->passSignalSelection()){
						bgMuCollection.push_back(itMu);
					}
				}

				std::vector< std::vector<recoPhoton>::iterator > bgPhoCollection;
				bgPhoCollection.clear();
				for(std::vector<recoPhoton>::iterator itpho = Photon.begin() ; itpho != Photon.end(); ++itpho){
					if(itpho->getCalibEt() < 30)continue;
					bool muFSRveto(true);
					for(std::vector<recoMuon>::iterator im = Muon.begin(); im != Muon.end(); im++)
				 		if(DeltaR(itpho->getEta(), itpho->getPhi(), im->getEta(), im->getPhi()) < 0.3 && im->getEt()>2.0)muFSRveto=false;
					if(muFSRveto && itpho->isLoose()){
				 		bgPhoCollection.push_back(itpho);
				 	}
			 	}

     		for(unsigned iPho(0); iPho < bgPhoCollection.size(); iPho++){
          for(unsigned iMu(0); iMu < bgMuCollection.size(); iMu++){
            std::vector<recoMuon>::iterator bgMu = bgMuCollection[iMu];
            std::vector<recoPhoton>::iterator bgPho = bgPhoCollection[iPho];
       			bool PixelVeto = bgPho->PixelSeed()==0? true: false;
       			bool GSFveto(true);
						bool FSRVeto(true);
       			for(std::vector<recoEle>::iterator ire = Ele.begin(); ire != Ele.end(); ire++){
         			if(ire->getCalibEt() > 2.0 && DeltaR(bgPho->getEta(), bgPho->getPhi(), ire->getEta(), ire->getPhi()) < 0.02)GSFveto=false;
							if(DeltaR(bgPho->getEta(), bgPho->getPhi(), ire->getEta(), ire->getPhi()) < 0.3 && ire->getCalibEt()>2.0)FSRVeto=false;
       			}

						 tagEta_mg = bgMu->getEta();
						 tagPhi_mg = bgMu->getPhi();
						 tagPt_mg = bgMu->getPt();
						 probeEta_mg = bgPho->getEta();
						 probePhi_mg = bgPho->getPhi();
						 probePt_mg = bgPho->getCalibEt();
						 probeUncalibPt_mg = bgPho->getEt();
						 invmass_mg = (bgPho->getCalibP4()+bgMu->getP4()).M();
						 vetovalue_mg = (PixelVeto && GSFveto);
						 FSRveto_mg = FSRVeto;

						 mtree->Fill();
           }
     		}

  }//loop on  events

cout<<"output tree entries: "<<mtree->GetEntries()<<endl;
output->Write();
output->Close();
logfile.close();

}

int main(int argc, char** argv)
{
    if(argc < 3)
      cout << "You have to provide two arguments!!\n";
    analysis_bgtemplate(argv[1],argv[2]);
    return 0;
}
